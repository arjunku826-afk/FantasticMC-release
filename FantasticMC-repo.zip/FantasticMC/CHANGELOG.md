# Changelog

## [0.53] - 2026-11-08
- Preview release published on GitHub.
- Floating gameplay HUD with editor and presets.
- `.mcpack` / `.mcaddon` import, skin editor, servers list, themes.
- Experimental built-in game mode (bring your own Minecraft APK, arm64).
