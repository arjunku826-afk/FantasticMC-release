#!/usr/bin/env bash
# Usage: ./publish.sh <github-username>/FantasticMC path/to/FantasticMC.apk
set -euo pipefail
REPO="$1"; APK="$2"
git init -b main
git add .
git commit -m "Initial commit"
gh repo create "$REPO" --public --source=. --push
cp "$APK" FantasticMC-v0.53.apk
gh release create v0.53 FantasticMC-v0.53.apk --title "FantasticMC v0.53 (preview)" --notes-file RELEASE_NOTES_v0.53.md --prerelease
rm FantasticMC-v0.53.apk
