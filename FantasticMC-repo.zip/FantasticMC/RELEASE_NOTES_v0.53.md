## FantasticMC v0.53 (preview)

A companion client for Minecraft: Bedrock Edition on Android.

**Highlights**
- Floating gameplay HUD with drag-and-drop editor and presets
- Import `.mcpack` / `.mcaddon` packs
- Skin editor and servers list
- Experimental built-in game mode (bring your own Minecraft APK)

**Requires:** Android 10+, arm64 device, Minecraft: Bedrock Edition

**SHA-256:** `888f9f4fce98f8383c7ce19160104a04c4612c827a711250e28d1df544902ee2`

This is an early preview. Please report bugs via Issues. Not affiliated with Mojang or Microsoft.
